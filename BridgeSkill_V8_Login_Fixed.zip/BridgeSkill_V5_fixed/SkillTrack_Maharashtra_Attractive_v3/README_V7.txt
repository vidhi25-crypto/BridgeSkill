BridgeSkill V7

This version uses the user's supplied Skills & Recommendations list as the source for the recommendation panel.

For each selected skill, BridgeSkill can show:
- Improve next
- Practice
- Job preparation / job-fast tips

The list contains 60 skills across technology/programming, creative, digital/business, professional and freelancing categories.

The recommendation panel is personalized to the skills the candidate actually added. It no longer gives Python/HTML practice advice to a photography/video-editing candidate unless those skills were actually selected.

The original skill-gap and job-matching features remain in the website.

Open index.html directly in Chrome. No Python/Flask required.
