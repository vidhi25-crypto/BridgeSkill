BridgeSkill V5

Why the old version only showed Python/JavaScript/Excel/etc:
The old demo had a small hard-coded job list, so job matching could only recognize those skills.

This version expands the prototype to include:
- Photography
- Videography
- Video Editing
- Adobe Photoshop / Lightroom
- Graphic Design
- UI/UX
- Digital Marketing
- Social Media Marketing
- Content Writing / Creation
- SEO
- Cybersecurity / Network Security
- Cloud / AWS
- Accounting / Tally
- Sales / Customer Service
- Java / C++ / React / Node.js / Mobile App Development
- Data Analysis / Visualization
- and more

It also accepts any custom skill. If that skill is connected to a job in the demo catalog, matching opportunities appear automatically.

Open index.html directly in Chrome. No Python or Flask required.
